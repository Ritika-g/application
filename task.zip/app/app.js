var express=require('express');
var app= express();
var bodyParser = require('body-parser');

//CONTROLLERS
var learningController=require('./controller/learningController');
var indexController=require('./controller/indexController');
var referenceController=require('./controller/referenceController');
var contentController=require('./controller/contentController');
var videoController=require('./controller/videoController');

//set template engine
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded())
app.use(bodyParser.json());

 

//fire Controller
learningController(app);
indexController(app);
contentController(app);
referenceController(app);
videoController(app);

app.use(express.static('./public'));

//listen to port 
app.listen(4000);

