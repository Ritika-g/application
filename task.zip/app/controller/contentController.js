var bodyParser = require("body-parser");
const fs = require("fs");
var urlencodedParser = bodyParser.urlencoded({ extended: false });


module.exports = function (app) {

  //get index
  app.get("/", function (req, res) {
    res.render("index1");


  });


function WriteToFile(data,callback) {
    const fileName = `./contentFiles/fileContent.txt`;
    var text = data;
    fs.mkdir('contentFiles', function () {
      fs.appendFile(fileName, text + "\n", 'utf8', function (err, data) {

        if (err) throw err;

        console.log("Data is appended to file successfully.")
        callback(text);
      });
    });

  }



  //post data of index
  app.post("/editContent", urlencodedParser, function (req, res) {
    WriteToFile(req.body.textarea1,function(callback){
     // console.log("hxnsjxjsjdxlkssssdhebnbdbhdjbd",callback );
    
   // res.render("show",{callback});

   
   res.redirect('/');
   });
    });
  }
 
    
    