var bodyParser = require("body-parser");
const fs = require("fs");

var urlencodedParser = bodyParser.urlencoded({ extended: false });
//var indexjson = require("../index.json");


module.exports = function (app) {


  



  //get editor
  app.get('/api/', function (req, res) {
    fs.readFile("index.json", function (err, fileData) {
      let jsondata = JSON.parse(fileData);
      console.log("content....." + jsondata);
    res.render('learning',{data: jsondata});
  });
  });

 

  app.post("/showContent", urlencodedParser, function (req, res) {

    res.send(data);
 
 
    });

app.post("/referenceShow", urlencodedParser, function (req, res) {
      res.send(data);
});

 app.get('/api/fetch_content', function (req, res) {
   
    const fileName = `./contentFiles/fileContent.txt`;
    fs.readFile(fileName, "utf8" ,(err, data) => {
      if (err) throw err;
      console.log(data);
      res.send(data);
      
    });
  
  });

  
 app.get('/api/ref_content', function (req, res) {
  const fileName = `./referenceFiles/refContent.txt`;
  fs.readFile(fileName, "utf8" ,(err, data) => {
    if (err) throw err;
    console.log(data);
    res.send(data);
    //readFromFile(req.body.showContent);
   // res.send(data);
  });


});
 app.get('/api/topic_content', function (req, res) {
  const fileName = `./topicFiles/topicContent.txt`;
 fs.readFile(fileName, "utf8" ,(err, data) => {

   

    if (err) throw err;
    
    res.send(data);
    //readFromFile(req.body.showContent);
   // res.send(data);
  });

});
app.get('/api/title_content', function (req, res) {
  const fileName = `./titleFiles/titleContent.txt`;
 fs.readFile(fileName, "utf8" ,(err, data) => {

   

    if (err) throw err;
    
    res.send(data);
    //readFromFile(req.body.showContent);
   // res.send(data);
  });

});


app.get('/api/video_content', function (req, res) {
  const file = `./videoFiles/videoContent.txt`;
 fs.readFile(file, "utf8" ,(err, data) => {

   

    if (err) throw err;
    console.log(data);
    res.send(data);
    //readFromFile(req.body.showContent);
   // res.send(data);
  });

});









 }