var bodyParser = require("body-parser");
const fs = require("fs");
var urlencodedParser = bodyParser.urlencoded({ extended: false });
 

module.exports = function(app){
 
    //get index
    app.get("/api",function(req,res){
        res.render("index1");
        

 
    });
        function WriteToFile(data,callback) {
        const fileName = `./referenceFiles/refContent.txt`;
        var text = data;
        fs.mkdir('referenceFiles', function () {
        fs.appendFile(fileName, text + "\n" , 'utf8', function (err, data) {
    
            if (err) throw err;
    
            console.log("Data is appended to file successfully.")
            callback(text);
          });
        });
    
      }


      app.post("/refContent", urlencodedParser, function (req, res) {
        WriteToFile(req.body.url,function(callback){
       // res.redirect('/api');
});
});






}
