var bodyParser = require("body-parser");
const fs = require("fs");
var urlencodedParser = bodyParser.urlencoded({ extended: false });


module.exports = function(app){
 
 
    //get index
    app.get("/",function(req,res){
        res.render("index1");
 
    });

  app.post("/editContent", urlencodedParser, function (req, res) {
    console.log(req.body);
      var index = req.body

    fs.readFile("Index.json", function (err, fileData) {
      if (err) {
        fs.writeFile("Index.json", function (err) {
          fs.readFile("Index.json", function (err, fileData) {
            let stringData = JSON.parse(fileData);
            stringData.push(index);
 
            fs.writeFile("Index.json", JSON.stringify(stringData), function (
              err
            ) {
              fs.readFile("Index.json", function (err, fileData) {
                let finalData = JSON.parse(fileData);
                console.log(finalData);
               // res.render("files", { data: finalData });
              });
            });
          });
        });
      } else {
        fs.readFile("Index.json", function (err, fileData) {
          let stringData;
          if (fileData.length > 0) {
            stringData = JSON.parse(fileData);
          } else {
            stringData = [];
          }
          stringData.push(index);
         
 
          fs.writeFile("Index.json", JSON.stringify(stringData), function (err) {
            fs.readFile("Index.json", function (err, fileData) {
              let finalData = JSON.parse(fileData);
              console.log(finalData);
             // res.render("files", { data: finalData });
            });
          });
        });
      }
    });
  });
  




   
  
  
  






    function WriteToFile(data,callback) {
        const fileName = `./topicFiles/topicContent.txt`;
        var text = data;
        fs.mkdir('topicFiles', function () {
          fs.appendFile(fileName, text +"\n", 'utf8', function (err, data) {
            if (err) throw err;
    
            console.log("Data is appended to file successfully.")
            callback(text);
          });
        }); 
    
      }
      function saveToFile(data,callback) {
        const fileName = `./titleFiles/titleContent.txt`;
        var text = data;
        fs.mkdir('titleFiles', function () {
          fs.appendFile(fileName, text +"\n", 'utf8', function (err, data) {
            if (err) throw err;
    
            console.log("Data is appended to file successfully.")
            callback(text);
          });
        }); 
    
      }

        app.post("/topicContent", urlencodedParser, function (req, res) {
        WriteToFile(req.body.text1,function(callback){

          // res.redirect('/');
        })
        });



        app.post("/chapter", urlencodedParser, function (req, res) {
          saveToFile(req.body.chapter,function(callback){
  
            // res.redirect('/');
          });
    
        });
  
  
        };

