const express = require('express');
  const multer = require('multer');
  const bodyParser = require('body-parser');
  const fs = require("fs");
 var Savedname = '';
 
 


  // SETUP APP
  const app = express();
  app.use(bodyParser.urlencoded({extended:false}));
  app.use(bodyParser.json());
  app.use('/', express.static(__dirname + '/public'));

 


module.exports = function(app){
  //MULTER CONFIG: to get file photos to temp server storage
  const multerConfig = {

 

    //specify diskStorage (another option is memory)
    storage: multer.diskStorage({

 

      //specify destination
      destination: function(req, file, next){
      next(null, './public/photo-storage');
      },

 

      //specify the filename to be unique
    filename: function(req, file, next){
      console.log("string" +JSON.stringify(file));
        //get the file mimetype ie 'image/jpeg' split and prefer the second value ie'jpeg'
        const ext = file.mimetype.split('/')[1];
       Savedname=file.originalname ;
     
        //set the file fieldname to a unique name containing the original name, current datetime and the extension.
        next(null, Savedname);
       // save file function call here and supply filename as parameter: saveFile(filename)
    
      }
    }),
         

 

    // filter out and prevent non-image files.
    fileFilter: function(req, file, next){
          if(!file){
            next();
          }
       
         
 

        // only permit image mimetypes
        const video = file.mimetype.startsWith('video/');
        if(video){
          console.log('video uploaded');
          next(null, true);
        }else{
          console.log("file not supported")
          //TODO:  A better message response to user on failure.
          return next();
        }
    }
  };

  
  function   WriteToFile (data,fileConfig,callback) {
    const file = `./videoFiles/videoContent.txt`;
    
  

    
    
    
    console.log(Savedname);
    fs.mkdir('videoFiles', function () {
      fs.writeFile(file,  Savedname+"\n", 'utf8', function (err, data) {
        if (err) throw err;
      
        console.log("Data is appended to file successfully.")
        
        callback(Savedname);
      });
    }); 

  }


 


 

  app.post('/upload', multer(multerConfig).single('video'),function(req, res){
    
   console.log('string');
    
      
   
     // res.json({videoname:callback});
// res.redirect('/');
    
  });
};
