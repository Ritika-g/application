var bodyParser = require("body-parser");
const fs = require("fs");
var urlencodedParser = bodyParser.urlencoded({ extended: false });


module.exports = function(app){
 
 
    //get index
    app.get("/",function(req,res){
        res.render("index1");
 
    });

  app.post("/editContent", urlencodedParser, function (req, res) {
  // console.log("hiiiii................." + JSON.stringify(req.body));
      var index = req.body
      
      var learning ={
        topic : req.body.topic,
         content :  req.body.content,
         reference :  req.body.reference,
         video :req.body.video,
        
      }
      

    fs.readFile("Index.json", function (err, fileData) {
      if (err) {
        fs.writeFile("Index.json", function (err) {
          fs.readFile("Index.json", function (err, fileData) {
            console.log("hiiiii" +fileData);
            let stringData = JSON.parse(fileData);
            stringData.push(index);
 
            fs.writeFile("Index.json", JSON.stringify(stringData), function (
              err
            ) {
              fs.readFile("Index.json", function (err, fileData) {
                let finalData = JSON.parse(fileData);
               // console.log(finalData);
               // res.render("files", { data: finalData });
              });
            });
          });
        });
      } else {
        fs.readFile("Index.json", function (err, fileData) {
          let stringData;
          if (fileData.length > 0) {
            stringData = JSON.parse(fileData);
          } else {
            stringData = [];
          }
          stringData.push(index);
         
 
          fs.writeFile("Index.json", JSON.stringify(stringData), function (err) {
            fs.readFile("Index.json", function (err, fileData) {
             /* let finalData = JSON.parse(fileData);  
              if(chapter[i]==chapter){
                fs.writeFile("Index.json",JSON.stringify(stringData.push(learning)),function (err){
                  fs.readFile("Index.json",function(err,fileData){
                    let finalData = JSON.parse(fileData);
                  })
                })
            

              }
              else
              fs.writeFile("Index.json",JSON.stringify(stringData),function(err){
                fs.readFile("Index.json",function(err,fileData){
                  let finalData = JSON.parse(fileData);  
                })
              })*/
              let finalData = JSON.parse(fileData);  
             // console.log(finalData);
             // res.render("files", { data: finalData });
            });
          });
        });
      }
    });
  });
  




   
  
  
  





}